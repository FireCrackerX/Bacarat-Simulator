import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.Image;
import java.awt.Toolkit;

public class App { 
    private JFrame f;
    private JButton player, banker, tie, playerPair, bankerPair, perfectPair;
    private JLabel lbTop1Panel, lbTop2Panel, bar, bar1, lbBottomPanel, lbMidPanel, p1, p2, p3, b1, b2, b3, lbBanker, lbPlayer;
    private ImageIcon questionMark, tsOverAdd, reg, bot, vs, imgP, imgPP, imgB, imgBP, imgT, imgPerP, youWin, youLose, playerW, playerI, playerN, bankerW, bankerI, bankerN, drawT, drawI, drawE; 
    private ImageIcon[] card = new ImageIcon[52];
    private Image icon;
    private String select;
    private ArrayList<Integer> memory;
    private Timer delay;
    private int tempSelect, valuePlayer = 0, valueBanker = 0, memCardPlayer1, memCardPlayer2, memCardBanker1, memCardBanker2;
    private int[] valueCard = {1,2,3,4,5,6,7,8,9,10,20,30,40,
                                1,2,3,4,5,6,7,8,9,10,20,30,40,
                                1,2,3,4,5,6,7,8,9,10,20,30,40,
                                1,2,3,4,5,6,7,8,9,10,20,30,40};
    private boolean isClicked = true;

    public static void main(String[] args) {
        App a = new App();
    }

    public App() {
        memory = new ArrayList<Integer>();
        f = new JFrame("Baccarat - TSOVER.COM");
        icon = Toolkit.getDefaultToolkit().getImage("card/icon.png");
        f.setIconImage(icon);
        f.setSize(1030,820);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        detailInitialization();
        f.setVisible(true);
    }
    private void detailInitialization(){
        try {
            questionMark = new ImageIcon(new ImageIcon("card/backcard.jpg").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            tsOverAdd = new ImageIcon(new ImageIcon("card/tsover-ads.gif").getImage().getScaledInstance(500, 100, Image.SCALE_DEFAULT));
            reg = new ImageIcon(new ImageIcon("card/reg111.gif").getImage().getScaledInstance(500, 105, Image.SCALE_DEFAULT));
            bot = new ImageIcon(new ImageIcon("card/banner-Joker888asia.gif").getImage().getScaledInstance(1000, 200, Image.SCALE_DEFAULT));
            youWin = new ImageIcon(new ImageIcon("card/YouWin.gif").getImage().getScaledInstance(1000, 200, Image.SCALE_DEFAULT));
            youLose = new ImageIcon(new ImageIcon("card/YouLose.gif").getImage().getScaledInstance(1000, 200, Image.SCALE_DEFAULT));
            vs = new ImageIcon(new ImageIcon("card/vs.gif").getImage().getScaledInstance(200, 200, Image.SCALE_DEFAULT));
            imgP = new ImageIcon(new ImageIcon("card/btnPlayer.png").getImage().getScaledInstance(150, 180, Image.SCALE_DEFAULT));
            imgPP = new ImageIcon(new ImageIcon("card/btnPlayerPair.png").getImage().getScaledInstance(125, 180, Image.SCALE_DEFAULT));
            imgB = new ImageIcon(new ImageIcon("card/btnBanker.png").getImage().getScaledInstance(150, 180, Image.SCALE_DEFAULT));
            imgBP = new ImageIcon(new ImageIcon("card/btnBankerPair.png").getImage().getScaledInstance(125, 180, Image.SCALE_DEFAULT));
            imgT = new ImageIcon(new ImageIcon("card/btnTie.png").getImage().getScaledInstance(100, 180, Image.SCALE_DEFAULT));
            imgPerP = new ImageIcon(new ImageIcon("card/btnPerfectPair.png").getImage().getScaledInstance(100, 180, Image.SCALE_DEFAULT));
            bankerW = new ImageIcon(new ImageIcon("card/WBanker.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            bankerI = new ImageIcon(new ImageIcon("card/IBanker.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            bankerN = new ImageIcon(new ImageIcon("card/NBanker.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            playerW = new ImageIcon(new ImageIcon("card/WPlayer.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            playerI = new ImageIcon(new ImageIcon("card/IPlayer.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            playerN = new ImageIcon(new ImageIcon("card/NPlayer.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            drawT = new ImageIcon(new ImageIcon("card/DrawT.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            drawI = new ImageIcon(new ImageIcon("card/DrawI.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            drawE = new ImageIcon(new ImageIcon("card/DrawE.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[0] = new ImageIcon(new ImageIcon("card/clubs/1 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[0] = new ImageIcon(new ImageIcon("card/clubs/1 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[1] = new ImageIcon(new ImageIcon("card/clubs/2 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[2] = new ImageIcon(new ImageIcon("card/clubs/3 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[3] = new ImageIcon(new ImageIcon("card/clubs/4 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[4] = new ImageIcon(new ImageIcon("card/clubs/5 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[5] = new ImageIcon(new ImageIcon("card/clubs/6 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[6] = new ImageIcon(new ImageIcon("card/clubs/7 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[7] = new ImageIcon(new ImageIcon("card/clubs/8 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[8] = new ImageIcon(new ImageIcon("card/clubs/9 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[9] = new ImageIcon(new ImageIcon("card/clubs/10 clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[10] = new ImageIcon(new ImageIcon("card/clubs/J clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[11] = new ImageIcon(new ImageIcon("card/clubs/Q clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[12] = new ImageIcon(new ImageIcon("card/clubs/K clubs.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[13] = new ImageIcon(new ImageIcon("card/diamonds/1 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[14] = new ImageIcon(new ImageIcon("card/diamonds/2 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[15] = new ImageIcon(new ImageIcon("card/diamonds/3 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[16] = new ImageIcon(new ImageIcon("card/diamonds/4 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[17] = new ImageIcon(new ImageIcon("card/diamonds/5 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[18] = new ImageIcon(new ImageIcon("card/diamonds/6 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[19] = new ImageIcon(new ImageIcon("card/diamonds/7 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[20] = new ImageIcon(new ImageIcon("card/diamonds/8 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[21] = new ImageIcon(new ImageIcon("card/diamonds/9 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[22] = new ImageIcon(new ImageIcon("card/diamonds/10 diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[23] = new ImageIcon(new ImageIcon("card/diamonds/J diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[24] = new ImageIcon(new ImageIcon("card/diamonds/Q diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[25] = new ImageIcon(new ImageIcon("card/diamonds/K diamonds.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[26] = new ImageIcon(new ImageIcon("card/hearts/1 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[27] = new ImageIcon(new ImageIcon("card/hearts/2 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[28] = new ImageIcon(new ImageIcon("card/hearts/3 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[29] = new ImageIcon(new ImageIcon("card/hearts/4 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[30] = new ImageIcon(new ImageIcon("card/hearts/5 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[31] = new ImageIcon(new ImageIcon("card/hearts/6 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[32] = new ImageIcon(new ImageIcon("card/hearts/7 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[33] = new ImageIcon(new ImageIcon("card/hearts/8 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[34] = new ImageIcon(new ImageIcon("card/hearts/9 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[35] = new ImageIcon(new ImageIcon("card/hearts/10 hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[36] = new ImageIcon(new ImageIcon("card/hearts/J hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[37] = new ImageIcon(new ImageIcon("card/hearts/Q hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[38] = new ImageIcon(new ImageIcon("card/hearts/K hearts.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[39] = new ImageIcon(new ImageIcon("card/spades/1 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[40] = new ImageIcon(new ImageIcon("card/spades/2 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[41] = new ImageIcon(new ImageIcon("card/spades/3 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[42] = new ImageIcon(new ImageIcon("card/spades/4 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[43] = new ImageIcon(new ImageIcon("card/spades/5 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[44] = new ImageIcon(new ImageIcon("card/spades/6 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[45] = new ImageIcon(new ImageIcon("card/spades/7 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[46] = new ImageIcon(new ImageIcon("card/spades/8 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[47] = new ImageIcon(new ImageIcon("card/spades/9 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[48] = new ImageIcon(new ImageIcon("card/spades/10 spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[49] = new ImageIcon(new ImageIcon("card/spades/J spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[50] = new ImageIcon(new ImageIcon("card/spades/K spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
            card[51] = new ImageIcon(new ImageIcon("card/spades/Q spades.png").getImage().getScaledInstance(125, 170, Image.SCALE_DEFAULT));
        } catch (Exception e) {
            System.out.println(e);
        }
        lbTop1Panel = new JLabel(tsOverAdd);
        lbTop2Panel = new JLabel(reg);
        bar = new JLabel();
        bar.setPreferredSize(new Dimension(1000,20));
        bar1 = new JLabel();
        bar1.setPreferredSize(new Dimension(190,30));
        p1 = new JLabel(questionMark);
        p1.setPreferredSize(new Dimension(125,170));
        p2 = new JLabel(questionMark);
        p2.setPreferredSize(new Dimension(125,170));
        p3 = new JLabel(questionMark);
        p3.setPreferredSize(new Dimension(125,170));
        lbMidPanel = new JLabel(vs);
        b1 = new JLabel(questionMark);
        b1.setPreferredSize(new Dimension(125,170));
        b2 = new JLabel(questionMark);
        b2.setPreferredSize(new Dimension(125,170));
        b3 = new JLabel(questionMark);
        b3.setPreferredSize(new Dimension(125,170));
        lbBottomPanel = new JLabel(bot);
        player = new JButton(imgP);
        player.setPreferredSize(new Dimension(150,180));
        playerPair = new JButton(imgPP);
        playerPair.setPreferredSize(new Dimension(125,180));
        tie = new JButton(imgT);
        tie.setPreferredSize(new Dimension(100,180));
        perfectPair = new JButton(imgPerP);
        perfectPair.setPreferredSize(new Dimension(100,180));
        bankerPair = new JButton(imgBP);
        bankerPair.setPreferredSize(new Dimension(125,180));
        banker = new JButton(imgB);
        banker.setPreferredSize(new Dimension(150,180));
        lbBanker = new JLabel("BANKER",SwingConstants.CENTER);
        lbBanker.setFont(new Font("Serif",Font.BOLD,30));
        lbBanker.setPreferredSize(new Dimension(395,30));
        lbPlayer = new JLabel("PLAYER",SwingConstants.CENTER);
        lbPlayer.setFont(new Font("Serif",Font.BOLD,30));
        lbPlayer.setPreferredSize(new Dimension(395,30));
        f.setLayout(new FlowLayout());
        f.add(lbTop1Panel);
        f.add(lbTop2Panel);
        f.add(bar);
        f.add(p1);
        f.add(p2);
        f.add(p3);
        f.add(lbMidPanel);
        f.add(b1);
        f.add(b2);
        f.add(b3);
        f.add(lbPlayer);
        f.add(bar1);
        f.add(lbBanker);
        f.add(player);
        f.add(playerPair);
        f.add(tie);
        f.add(perfectPair);
        f.add(bankerPair);
        f.add(banker);
        f.add(lbBottomPanel);

        AllbtnListener lis = new AllbtnListener();
        player.addActionListener(lis);
        playerPair.addActionListener(lis);
        tie.addActionListener(lis);
        perfectPair.addActionListener(lis);
        bankerPair.addActionListener(lis);
        banker.addActionListener(lis);
    }
    private class AllbtnListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ev) {
            JButton source = (JButton) ev.getSource();
            if((source == player) && isClicked){
                select = "Player";
                isClicked = false;
                play();
            }
            else if((source == playerPair) && isClicked){
                select = "PlayerPair";
                isClicked = false;
                play();
            }
            else if((source == tie) && isClicked){
                select = "Tie";
                isClicked = false;
                play();
            }
            else if((source == perfectPair) && isClicked){
                select = "PerfectPair";
                isClicked = false;
                play();
            }
            else if((source == bankerPair) && isClicked){
                select = "BankerPair";
                isClicked = false;
                play();
            }
            else if((source == banker) && isClicked){
                select = "Banker";
                isClicked = false;
                play();
            }
        }
    }
    public void play() {
        ActionListener action = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tempSelect = randomCard();
                p1.setIcon(card[tempSelect]);
                valuePlayer += valueCard[tempSelect];
                memCardPlayer1 = valueCard[tempSelect];
            }
        };
        delay = new Timer(500,action);
        delay.start();
        delay.setRepeats(false);
        action = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tempSelect = randomCard();
                b1.setIcon(card[tempSelect]);
                valueBanker += valueCard[tempSelect];
                memCardBanker1 = valueCard[tempSelect];
            }
        };
        delay = new Timer(1000,action);
        delay.start();
        delay.setRepeats(false);

        action = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tempSelect = randomCard();
                p2.setIcon(card[tempSelect]);
                valuePlayer += valueCard[tempSelect];
                valuePlayer %= 10;
                memCardPlayer2 = valueCard[tempSelect];
            }
        };
        delay = new Timer(2000,action);
        delay.start();
        delay.setRepeats(false);

        action = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tempSelect = randomCard();
                b2.setIcon(card[tempSelect]);
                valueBanker += valueCard[tempSelect];
                valueBanker %= 10;
                memCardBanker2 = valueCard[tempSelect];
                if(valueBanker>7||valuePlayer>7){
                    delay.stop();
                    if(valueBanker>valuePlayer){
                        bankerWin();
                    }
                    else if(valueBanker<valuePlayer){
                        playerWin();
                    }
                    else if(valueBanker==valuePlayer){
                        draw();
                    }
                }
            }
        };
        delay = new Timer(2500,action);
        delay.start();
        delay.setRepeats(false);

        action = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tempSelect = randomCard();
                if(valueBanker>7||valuePlayer>7){
                    
                }
                else if(valueBanker>5&&valuePlayer>5){
                    p3.setIcon(card[tempSelect]);
                    valuePlayer += valueCard[tempSelect];
                    valuePlayer %= 10;
                }
                else if(valuePlayer<=5){
                    p3.setIcon(card[tempSelect]);
                    valuePlayer += valueCard[tempSelect];
                    valuePlayer %= 10; 
                }
            }
        };
        delay = new Timer(4000,action);
        delay.start();
        delay.setRepeats(false);

        action = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                tempSelect = randomCard();
                if(valueBanker<=5){
                    b3.setIcon(card[tempSelect]);
                    valueBanker += valueCard[tempSelect];
                    valueBanker %= 10;
                }
                if(valueBanker>valuePlayer){
                    bankerWin();
                }
                else if(valueBanker<valuePlayer){
                    playerWin();
                }
                else if(valueBanker==valuePlayer){
                    draw();
                }
            }
        };
        delay = new Timer(4500,action);
        delay.start();
        delay.setRepeats(false);
    }
    public void newGame() {
        p1.setIcon(questionMark);
        p2.setIcon(questionMark);
        p3.setIcon(questionMark);
        b1.setIcon(questionMark);
        b2.setIcon(questionMark);
        b3.setIcon(questionMark);
        lbBottomPanel.setIcon(bot);
        isClicked = true;
        valueBanker = 0;
        valuePlayer = 0;
        memory = new ArrayList<Integer>();
    }
    public void bankerWin() {
        ActionListener actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                b1.setIcon(playerW);
                if(select.equals("PerfectPair")){
                    if(memCardBanker1 == memCardBanker2 && memCardPlayer1 == memCardBanker2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("BankerPair")){
                    if(memCardBanker1 == memCardBanker2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("PlayerPair")){
                    if(memCardPlayer1 == memCardPlayer2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("Banker")){
                    lbBottomPanel.setIcon(youWin);
                }
                else{
                    lbBottomPanel.setIcon(youLose);
                }
            }
        };
        delay = new Timer(3200,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                b2.setIcon(playerI);
            }
        };
        delay = new Timer(3400,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                b3.setIcon(playerN);
            }
        };
        delay = new Timer(3600,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        };
        delay = new Timer(6000,actionWin);
        delay.start();
        delay.setRepeats(false);
    }
    public void playerWin() {
        ActionListener actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                p1.setIcon(bankerW);
                if(select.equals("PerfectPair")){
                    if(memCardBanker1 == memCardBanker2 && memCardPlayer1 == memCardBanker2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("BankerPair")){
                    if(memCardBanker1 == memCardBanker2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("PlayerPair")){
                    if(memCardPlayer1 == memCardPlayer2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("Player")){
                    lbBottomPanel.setIcon(youWin);
                }
                else{
                    lbBottomPanel.setIcon(youLose);
                }
            }
        };
        delay = new Timer(3200,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                p2.setIcon(bankerI);
            }
        };
        delay = new Timer(3400,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                p3.setIcon(bankerN);
            }
        };
        delay = new Timer(3600,actionWin);
        delay.start();
        delay.setRepeats(false);
        
        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        };
        delay = new Timer(6000,actionWin);
        delay.start();
        delay.setRepeats(false);
    }
    public void draw() {
        ActionListener actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                p1.setIcon(drawT);
                b3.setIcon(drawT);
                if(select.equals("PerfectPair")){
                    if(memCardBanker1 == memCardBanker2 && memCardPlayer1 == memCardBanker2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("BankerPair")){
                    if(memCardBanker1 == memCardBanker2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("PlayerPair")){
                    if(memCardPlayer1 == memCardPlayer2){
                        lbBottomPanel.setIcon(youWin);
                    }
                    else{
                        lbBottomPanel.setIcon(youLose);
                    }
                }
                else if(select.equals("Tie")){
                    lbBottomPanel.setIcon(youWin);
                }
                else{
                    lbBottomPanel.setIcon(youLose);
                }
            }
        };
        delay = new Timer(3200,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                p2.setIcon(drawI);
                b2.setIcon(drawI);
            }
        };
        delay = new Timer(3400,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                p3.setIcon(drawE);
                b1.setIcon(drawE);
            }
        };
        delay = new Timer(3600,actionWin);
        delay.start();
        delay.setRepeats(false);

        actionWin = new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        };
        delay = new Timer(6000,actionWin);
        delay.start();
        delay.setRepeats(false);
    }
    public int randomCard() {
        Random rd = new Random();
        int number = rd.nextInt(52);
        for(int i=0;i<memory.size();i++){
            if(number == memory.get(i)){
                number = rd.nextInt(52);
                i = -1;
            }
        }
        memory.add(number);
        return number;
    }
}
